from flask import Flask, render_template, request, redirect, make_response, session, url_for, flash
from flask_moment import Moment
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
moment = Moment(app)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///database.db"
app.config['SECRET_KEY'] = "hard to guess string"
HOST = '0.0.0.0'
PORT = 5000
server_address = '127.0.0.1:5000'
db = SQLAlchemy(app)

@app.route('/')
def index():
    return render_template("Index.html")

@app.route('/product')
def product():
    return render_template("product.html")

@app.route('/Rules_and_laws')
def Rules_and_laws():
    return render_template("Rules_and_laws.html")

@app.route('/rules')
def rules():
    return render_template("rules.html")

@app.route('/law')
def law():
    return render_template("law_on_hunting_and_fishing.html")

@app.route('/Providing')
def Providing():
    return render_template("Providing_legal_assistance.html")

@app.route('/Courses')
def Courses():
    return render_template("Courses.html")

@app.route('/login')
def login():
    return render_template("login.html")

@app.route('/register')
def register():
    return render_template("register.html")

@app.route('/profile')
def profile():
    return render_template("profile.html")

@app.route('/About')
def about():
    return render_template("About.html")

@app.route('/Admin')
def admin():
    return render_template("Admin.html")

@app.route('/Account_table')
def account_table():
    return render_template("Account_table.html")
    
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

if __name__ == "__main__":
    app.run(debug=True, host=HOST, port=PORT)